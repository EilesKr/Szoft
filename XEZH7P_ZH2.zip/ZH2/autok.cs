﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH2
{
    public class autok
    {
        //AutoID,Modell,Gyarto,Evjarat,Uzemanyag,TeljesitmenyHP
        public int AutoID { get; set; }
        public string Modell { get; set; }
        public string Gyarto { get; set;}
        public int Evjarat { get; set; }
        public string Uzemanyag { get; set; }
        public int TeljesitmenyHP { get; set; }
    }
}
